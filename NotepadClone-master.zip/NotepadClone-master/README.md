NotepadClone
============
A Notepad Clone written in C# WinForms.

Read more on my blog: 
http://www.simplygoodcode.com/2012/04/notepad-clone-in-net-winforms/

I use notepad all the time, sometimes I just wanted to add one little feature, but it�s not extendable so I can�t. If I could just get my hands on the source code and if that source code was in C# I�d be set. So I decided to write a clone so I can do just that, and share it so that others could as well.

I attempted to make an exact clone and I think I did pretty good with three exceptions. One I decided I wanted a different icon so I can tell it apart from the actual notepad. Two, the real notepad has header and footer information as part of the page setup. I didn�t know how to do that since the page setup dialog is a system dialog. And three I didn�t try to duplicate the windows notepad help file.