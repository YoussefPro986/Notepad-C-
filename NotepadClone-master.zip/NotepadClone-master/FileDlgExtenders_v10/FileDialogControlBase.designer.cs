namespace FileDialogExtenders
{
    partial class FileDialogControlBase
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;



        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.SuspendLayout();
            // 
            // FileDialogControlBase
            // 
            this.Name = "FileDialogControlBase";
            this.Size = new System.Drawing.Size(555, 385);
            this.ResumeLayout(false);

        }

        #endregion


        //protected System.Windows.Forms.OpenFileDialog _dlgOpen;



    }
}